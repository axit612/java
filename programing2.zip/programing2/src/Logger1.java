import java.util.logging.Logger;

public class Logger1 {

    private static final Logger logger = Logger.getLogger(Logger1.class.getName());

    static void sum(int a, int b) {
        logger.info("logger() method started");
        int sum = a + b;
        logger.info("sum is :" + sum);
        logger.info("logger() method ended");
    }

    public static void main(String[] args) {
        sum(5, 10);
    }
}