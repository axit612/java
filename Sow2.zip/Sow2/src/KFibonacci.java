public class KFibonacci {

    public static void main(String[] args) {

        int N = 10;   // find Nth term
        int K = 3;    // k-fibonacci

        int[] arr = new int[N];

        // first K elements
        for (int i = 0; i < K; i++) {
            arr[i] = 1;
        }

        // sum of first K elements
        int sum = K;

        // (K+1)th element
        if (K < N) {
            arr[K] = sum;
        }

        // remaining elements
        for (int i = K + 1; i < N; i++) {
            arr[i] = sum - arr[i - K - 1] + arr[i - 1];
            sum = arr[i];
        }

        // print Nth term
        System.out.println("Nth term: " + arr[N - 1]);
    }
}