import java.io.*;

public class Byte_IO {
    public static void main(String ap[])throws IOException{
        FileOutputStream fos = new FileOutputStream("data.txt");
        String text = "Hello java File Stream";

        fos.write(text.getBytes());
        fos.close();

        System.out.println("Data written to file");

        FileInputStream fis = new FileInputStream("data.txt");
        int ch;
        while ((ch = fis.read()) != -1){
            System.out.print((char) ch);
        }
        fis.close();
    }
}