public class Asynchronous {
    static void task1() {
        System.out.println("Task 1 started");
        try {
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Task 1 completed");
    }

    static void task2() {
        System.out.println("Task 2 started");
        System.out.println("Task 2 completed");
    }

    public static void main(String[] args) {

        Thread t1 = new Thread(() -> task1());
        Thread t2 = new Thread(() -> task2());

        t1.start();
        t2.start();
    }
}
