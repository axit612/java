public class NearestPalindrome {

    static boolean isPalindrome(int n) {
        int rev = 0, temp = n;
        while (temp > 0) {
            rev = rev * 10 + temp % 10;
            temp /= 10;
        }
        return rev == n;
    }

    public static void main(String[] args) {
        int n = 20;   // input number
        int left = n - 1;
        int right = n + 1;

        while (true) {
            if (isPalindrome(left) && isPalindrome(right)) {
                System.out.println("Average: " + (left + right) / 2);
                break;
            }
            if (isPalindrome(left)) {
                System.out.println("Closest Palindrome: " + left);
                break;
            }
            if (isPalindrome(right)) {
                System.out.println("Closest Palindrome: " + right);
                break;
            }
            left--;
            right++;
        }
    }
}