class test{
    int a = 20;
    int b = 21;
    String sum(){
        String sum1 = (a>b)? "a is max":"b is max";
        return sum1;
    }
}

public class TernaryOperator {
    public static void main(String args[]){
        test d = new test();
        String value =  d.sum();
        System.out.println(value);
    }
}
