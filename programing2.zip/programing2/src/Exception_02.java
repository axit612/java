public class Exception_02 {
    static void divide(int a,int b)throws ArithmeticException{
        int result = a/b;
        System.out.println("RESULT = "+result);
    }
    public static void main(String s[]){
        try {
                divide(10,0);
        }
        catch (ArithmeticException e){
            System.out.println("Exception handled in main");
        }
    }
}
