class demo{
    private class inner{
        void show(){
            System.out.println("Private Inner Class");
        }
    }

    void display(){
        inner in = new inner();
        in.show();
    }
}

public class program2 {

    public static void main(String args[]) {
        demo de = new demo();
        de.display();
    }
}
