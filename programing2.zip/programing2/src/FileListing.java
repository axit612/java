import java.io.File;

public class FileListing {
    static void list(File file) {

        File[] files = file.listFiles();

        if (files != null) {
            for (File f : files) {

                if (f.isDirectory()) {
                    System.out.println("Directory: " + f.getName());
                    list(f);
                } else {
                    System.out.println("File: " + f.getName());
                }
            }
        }
    }

    public static void main(String[] args) {
        File dir = new File(".");
        list(dir);
    }
}
