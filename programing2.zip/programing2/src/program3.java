
class demo1{
    static int x = 10;
    static class p3{

        void show(){
            System.out.println("x is a :" + x);
        }
    }
}

public class program3 {
    public static void main(String args[]){
        demo1.p3 p= new demo1.p3();
        p.show();
    }
}
