import java.util.*;

public class Wrapper {
    public static void main(String[] args) {

        // Autoboxing conversion of primitive → object
        int a = 10;
        Integer obj = a;

        // Unboxing Object → primitive
        int b = obj;

        System.out.println("Primitive value a: " + a);
        System.out.println("Wrapper object obj: " + obj);
        System.out.println("Unboxed value b: " + b);

        // String to int
        String s = "123";
        int num = Integer.parseInt(s);
        System.out.println("String to int: " + num);

        // Wrapper methods
        Integer x = 50;

        System.out.println("Max value: " + Integer.max(10, x));
        System.out.println("Min value: " + Integer.min(10, x));
        System.out.println("Compare: " + Integer.compare(10, x));

        // Using wrapper in collection
        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
        list.add(20);
        list.add(30);

        System.out.println("ArrayList values:");
        for (Integer i : list) {
            System.out.println(i);
        }
    }
}
