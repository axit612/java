public class Str {
    public static void main(String[] args){
        String s1 = "  Hello Java World  ";
        String s2 = "Java";

        System.out.println("Original String: " + s1);

        // length
        System.out.println("Length: " + s1.length());

        // trim
        System.out.println("Trimmed: " + s1.trim());

        // uppercase & lowercase
        System.out.println("Uppercase: " + s1.toUpperCase());
        System.out.println("Lowercase: " + s1.toLowerCase());

        // charAt
        System.out.println("Character at index 1: " + s1.charAt(2));

        // contains
        System.out.println("Contains 'Java': " + s1.contains(s2));

        // equals
        System.out.println("Equals 'java': " + s2.equals("java"));
        System.out.println("Equals Ignore Case: " + s2.equalsIgnoreCase("java"));

        // substring
        System.out.println("Substring: " + s1.substring(2, 7));

        // replace
        System.out.println("Replace Java with Python: " + s1.replace("Java", "Python"));

        // concat
        System.out.println("Concat: " + s2.concat(" Programming"));

        // split
        String[] words = s1.trim().split(" ");
        System.out.println("Split words:");
        for (String word : words) {
            System.out.println(word);
        }
    }
}
