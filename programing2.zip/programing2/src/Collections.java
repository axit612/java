import java.util.*;

public class Collections {
    // Method for List
    static void listExample() {
        List<String> list = new ArrayList<>();
        list.add("Java");
        list.add("Python");
        list.add("Java"); // duplicate allowed

        System.out.println("\nList elements:");
        for (String s : list) {
            System.out.println(s);
        }
    }

    // Method for Set
    static void setExample() {
        Set<Integer> set = new HashSet<>();
        set.add(10);
        set.add(20);
        set.add(10); // duplicate not allowed

        System.out.println("\nSet elements:");
        for (int n : set) {
            System.out.println(n);
        }
    }

    // Method for Map
    static void mapExample() {
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "Amit");
        map.put(2, "Neha");
        map.put(1, "Ravi"); // overwrites value

        System.out.println("\nMap elements:");
        for (Map.Entry<Integer, String> e : map.entrySet()) {
            System.out.println(e.getKey() + " = " + e.getValue());
        }
    }

    public static void main(String[] args) {
        listExample();
        setExample();
        mapExample();
    }
}
