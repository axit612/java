import java.util.concurrent.TransferQueue;

class math{
    int add(int a,int b){
      return a+b;
    }

    int add(int a,int b,int c){
        return a+b+c;
    }

    double add(double a,double b){
        return a+b;
    }
}

class mythread extends Thread{
    @Override
    public void run(){
        math m = new math();
        int sum1 = m.add(12,55);
        int sum2 = m.add(12,34,55);
        double sum3 = m.add(12.23,24.45);
        System.out.print("sun of a + b" + sum1);
        System.out.print("sun of a + b + c" + sum2);
        System.out.print("sun of a + b + c" + sum3);
    }
}


public class Polymorphism_program4_3 {

    public static void mian(String args[]){
        System.out.println("========================Start Program=====================");
        mythread thread = new mythread();
        thread.start();
        System.out.println("========================End Program=====================");
    }
}
