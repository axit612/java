package JDBC;
import java.sql.*;
public class connect {
    public static void main(String a[]){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/login","root","");
            System.out.println("Connected.");
            Statement sta = con.createStatement();
//            int rows = sta.executeUpdate("INSERT INTO `users`(`name`, `email`, `password`) VALUES ('axit3','axit3@gmail.com','1234567')");
//            System.out.println(rows + " record inserted");
            ResultSet rs = sta.executeQuery("SELECT * FROM users where id = 1");
            while (rs.next()){
                int id =  rs.getInt("id");
                String name =  rs.getString("name");
                String password = rs.getString("password");

                System.out.println(id+" "+ name + " " + password);
            }

        }catch (Exception e) {
            System.out.println(e);
        }
    }
}
