import java.util.List;
import java.util.stream.Stream;
import java.util.Arrays;

class Crud1 {
    void create_Stream() {
        Stream<String> stream = Stream.of("Java", "Python", "C++");
        stream.forEach(System.out::println);
    }

    void StreamFromList(){
        List<String> languages = Arrays.asList("Java","Python","JavaScript");
        languages.stream().forEach(System.out::println);
    }

    void UseStream(){
        List<Integer> number = Arrays.asList(10,13,14,15,34,56);
        number.stream().filter(n->n>20).forEach(System.out::println);
    }

    void UseStreammap(){
        List<String> names = Arrays.asList("java","stream","api");
        names.stream().map(String::toUpperCase).forEach(System.out::println);
    }

    void UseStreamflatMap(){
        List<List<String>> list = Arrays.asList(
                Arrays.asList("Java", "Python"),
                Arrays.asList("Spring", "Hibernate")
        );
        list.stream()
                .flatMap(innerList -> innerList.stream())
                .forEach(System.out::println);
    }

    void Streamdistinct(){
        List<Integer> numbers = Arrays.asList(1, 2, 2, 3, 4, 4, 5);

        numbers.stream()
                .distinct()
                .forEach(System.out::println);
    }
}

public class Stream_program {
    public static void main(String[] args) {
        Crud1 c = new Crud1();
        c.create_Stream();
        c.StreamFromList();
        c.UseStream();
        c.UseStreammap();
        c.Streamdistinct();
        c.UseStreamflatMap();
    }
}