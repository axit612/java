

public class Exception_03 {
    static void checkage(int Age){
        if(Age < 18){
            throw new ArithmeticException("Not eligible to vote");
        }
        else{
            System.out.println("Eligible to vote");
        }
    }
    public static void main(String args[]){
        try {
            checkage(14);
        }
        catch (ArithmeticException e){
            System.out.println("Exception caught : "+e.getMessage());
        }
        finally {
            System.out.println("Finally block executed");
        }
    }
}
