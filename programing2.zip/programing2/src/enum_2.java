public class enum_2 {
    enum stud{
        axit,krish,charmi,kushi,archna
    }
    public static void main(String args[]){
        stud s = stud.charmi;
        System.out.println("username is :"+s);
    }
}
