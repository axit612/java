enum stud{
    axit,rajan,arpit,jay
}
public class enum_1 {
    public static void main(String a[]){
        stud s = stud.axit;
        System.out.println(s);
    }
}
