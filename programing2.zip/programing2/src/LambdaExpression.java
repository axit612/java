import java.util.*;
import java.util.ArrayList;
import java.awt.List;

@FunctionalInterface
interface NoParam{
    void show();
}

@FunctionalInterface
interface Singleparam{
    void print(String msg);
}

@FunctionalInterface
interface MultipleParam{
    int add(int a,int b);
}
public class LambdaExpression {
    public static void main(String s[]) throws UnsupportedOperationException{

        try {
            //no perameter lambda expression
            NoParam n = () -> System.out.println("No parameter lambda expression");
            n.show();

            //Single parameter
            Singleparam s1 = msg -> System.out.println("Message: "+msg);
            s1.print("Single parameter");

            //Multiple Parameter Lambda
            MultipleParam m1 = (a,b) -> {return a+b;};
            System.out.println("Sum witout return keyword:"+ m1.add(20,30));

            //Multiple Parameter Lambda
            MultipleParam m2 = (a,b) -> a+b;
            System.out.println("Sum of to number"+m2.add(12,34));

            //Lambda with forEach loop
//            List<String> list = Arrays.asList("Java", "Python", "C++");
//            System.out.println("forEach using lambda:");
//            list.forEach(lang -> System.out.println(lang));

            //Lambda with multiple statements
            Singleparam multiStmt = msg -> {
                System.out.println("Multiple statement lambda");
                System.out.println("Message received: " + msg);
            };
            multiStmt.print("Hello Lambda");

            // Lambda expression to run a thread
            Runnable r = () -> System.out.println("Thread running using lambda expression");
            Thread t = new Thread(r);
            t.start();

            // Lambda with Comparator
//            List<Integer> numbers = Arrays.asList(5, 1, 8, 3);
//            Collections.sort(numbers, (a, b) -> a - b);
//            System.out.println("Sorted numbers using lambda comparator: " + numbers);
        }catch (Exception e){
            System.out.println(e);
        }


    }
}
