class Exception_01 {
    public static void main(String[] args) {

        try {
            int a = 10 / 0;          // ArithmeticException
            int[] arr = {1, 2};
            System.out.println(arr[5]); // ArrayIndexOutOfBoundsException
        }
        catch (ArithmeticException e) {
            System.out.println("Arithmetic Exception handled");
        }
        catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array Index Exception handled");
        }
        catch (Exception e) {
            System.out.println("General Exception handled");
        }

        System.out.println("Program continues...");
    }
}