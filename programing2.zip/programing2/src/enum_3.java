import java.sql.Statement;
import java.util.*;
enum TrafficLight {
    RED, YELLOW, GREEN
}

public class enum_3 {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int data=0;
        do {
            System.out.println("Enter number (1-RED, 2-YELLOW, 3-GREEN):");
            data = sc.nextInt();
            TrafficLight signal = null;
            switch (data) {
                case 1:
                    signal = TrafficLight.RED;
                    break;
                case 2:
                    signal = TrafficLight.YELLOW;
                    break;
                case 3:
                    signal = TrafficLight.GREEN;
                    break;
                case 4:
                    System.out.println("Thank you for Stop");
                    break;
            }

            switch (signal) {
                case RED:
                    System.out.println("Stop");
                    break;
                case YELLOW:
                    System.out.println("Get Ready");
                    break;
                case GREEN:
                    System.out.println("Go");
                    break;
            }
        }while (data!=4);
    }
}
