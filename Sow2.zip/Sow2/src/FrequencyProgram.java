import java.util.HashMap;
import java.util.Map;

public class FrequencyProgram {

    public static void main(String[] args) {

        String text = "I went to the store to buy some milk, but when I got there, "
                + "I discovered that the store      was out of milk and I had to go "
                + "to another store to find some milk.";

        // CHARACTER FREQUENCY
        Map<Character, Integer> charMap = new HashMap<>();

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);

            if (ch != ' ') {   // ignore spaces
                if (charMap.containsKey(ch)) {
                    charMap.put(ch, charMap.get(ch) + 1);
                } else {
                    charMap.put(ch, 1);
                }
            }
        }

        // WORD FREQUENCY
        Map<String, Integer> wordMap = new HashMap<>();

        // replace comma and dot
        text = text.replace(",", "").replace(".", "");

        String[] words = text.split("\\s+");

        for (int i = 0; i < words.length; i++) {
            if (wordMap.containsKey(words[i])) {
                wordMap.put(words[i], wordMap.get(words[i]) + 1);
            } else {
                wordMap.put(words[i], 1);
            }
        }


        System.out.println("Frequency of characters: " + text.length());
        System.out.println("Frequency of words: " + words.length);

        System.out.println("\nTop 9 frequent characters:");
        printHighest(charMap, 9);

        System.out.println("\nLeast 9 frequent characters:");
        printLowest(charMap, 9);

        System.out.println("\nTop 9 frequent words:");
        printHighest(wordMap, 9);

        System.out.println("\nLeast 9 frequent words:");
        printLowest(wordMap, 9);
    }

    // PRINT HIGHEST
    static <T> void printHighest(Map<T, Integer> map, int limit) {
        for (int i = 0; i < limit; i++) {
            T maxKey = null;
            int maxValue = 0;

            for (T key : map.keySet()) {
                if (map.get(key) > maxValue) {
                    maxValue = map.get(key);
                    maxKey = key;
                }
            }

            if (maxKey != null) {
                System.out.println(maxKey + ": " + maxValue);
                map.remove(maxKey);
            }
        }
    }

    // PRINT LOWEST
    static <T> void printLowest(Map<T, Integer> map, int limit) {
        for (int i = 0; i < limit; i++) {
            T minKey = null;
            int minValue = Integer.MAX_VALUE;

            for (T key : map.keySet()) {
                if (map.get(key) < minValue) {
                    minValue = map.get(key);
                    minKey = key;
                }
            }

            if (minKey != null) {
                System.out.println(minKey + ": " + minValue);
                map.remove(minKey);
            }
        }
    }
}