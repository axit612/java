import java.io.*;
import java.util.*;

public class CRUD {
    public static void main(String s[]) throws IOException{
        Scanner sc = new Scanner(System.in);
        String fileName;

        int n;
        do{
            System.out.println("\nEnter 1 for Create new file : ");
            System.out.println("Enter 2 for Write in file : ");
            System.out.println("Enter 3 for Read in file : ");
            System.out.println("Enter 4 for Delete file : ");
            System.out.println("Enter 5 for Create Directory : ");
            System.out.println("Enter 6 for Delete Directory : ");
            System.out.println("Enter 7 for Exit : ");
            System.out.println("Enter the Numner : ");
            n = sc.nextInt();
            switch (n){
                case 1:
                    System.out.print("Enter the file Name :");
                    fileName = sc.next();
                    File file = new File(fileName+".txt");

                    if(file.createNewFile()){
                        System.out.println("File created");
                    }else {
                        System.out.println("File already Exists");
                    }
                    break;
                case 2:
                    System.out.print("Enter the file Name :");
                    fileName = sc.next();
                    FileWriter fw = new FileWriter(fileName+".txt");
                    //String data = sc.nextLine();
                    fw.write("Hello my name is a axit");
                    fw.close();
                    break;
                case 3:
                    System.out.print("Enter the file Name :");
                    fileName = sc.next();
                    FileReader fr = new FileReader(fileName+".txt");
                    int ch;
                    while ((ch = fr.read())!=-1){
                        System.out.print((char)ch);
                    }
                    fr.close();
                    break;
                case 4:
                    System.out.print("Enter the file Name :");
                    fileName = sc.next();
                    File dir = new File(fileName+".txt");
                    if(dir.delete()){
                        System.out.println("File deleted");
                    }else {
                        System.out.println("File not found");
                    }
                    break;
                case  5:
                    File di = new File("MYjavaFolder");
                    if(di.mkdir()){
                        System.out.println("Directory created");
                    }else {
                        System.out.println("Directory already exists");
                    }
                    break;
                case  6:
                    File di1 = new File("MYjavaFolder");
                    if(di1.delete()){
                        System.out.println("Directory deleted");
                    }else {
                        System.out.println("Directory not deleted");
                    }
                    break;
                case  7:
                    break;
            }
        }while (n!=7);
    }
}
