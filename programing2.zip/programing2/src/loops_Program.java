class p4{
    void forloop(){
        for(int i=0;i<10;i++){
            for (int j=0;j<10;j++){
                if(i==0|| i==4 || j==0 || j==9) {
                    System.out.print(" * ");
                }
                else {
                    System.out.print("   ");
                }
            }
            System.out.println();
        }
    }

    void dowhile(){
        int n=1;
        do{
            System.out.print(n);
            n++;
        }while(n!=10);
    }


}

public class loops_Program {
    public static void main(String args[]){
        p4 p = new p4();
        p.forloop();
        p.dowhile();
    }
}
