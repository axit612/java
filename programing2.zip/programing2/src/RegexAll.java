import java.util.regex.*;

public class RegexAll {
    public static void main(String s[]){

        // matches()
        String text1 = "Axit612";
        System.out.println("match letters & digits : " + text1.matches("[A-Za-z0-9]+"));

        //pasttern & mAtcher
        Pattern p = Pattern.compile("java");
        Matcher m = p.matcher("java is java powerful");

        System.out.println("\nFinding word 'Java':");
        while (m.find()){
            System.out.println("Found at index "+m.start()+" to "+ m.end());
        }

        // character classes
        String number = "12345";
        System.out.println("\n Only digits: "+number.matches("\\d+"));

        //Quantifiers
        String name = "Axit";
        System.out.println("alphabets (min 3)"+name.matches("[A-za-z]{3,}"));

        //Email validation
        String email = "axit@gmail.com";
        String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
        System.out.println("Valid Email:"+email.matches(emailRegex));

        //replaceAll()
        String mixed = "Java123Language";
        String result = mixed.replaceAll("\\d","");
        System.out.println("\nAfter Removing digits: "+result);

        //split
        String data = "java Python c++";
        String[] langs = data.split(" ");

        System.out.println("\nSplit result:");
        for (String lang:langs){
            System.out.println(lang);
        }

    }
}



//matches() → full string match

//Pattern → compiled regex

//Matcher → search text

//find() → find pattern

//start() / end() → match position

//\\d → digits

//{3,} → minimum length

//replaceAll() → replace using regex

//split() → split string