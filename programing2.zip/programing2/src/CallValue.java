class callobj {
    int data = 20;

    static void change(int x) {
        x = 50;  // Call by Value
        System.out.println("Value of x inside method: " + x);
    }
}

public class CallValue {

    static void call(callobj d) {
        d.data = 99;  // Call by Reference
        System.out.println("callobj data in method: " + d.data);
    }

    public static void main(String[] args) {

        // Call by Reference
        callobj obj = new callobj();
        call(obj);
        System.out.println("callobj data in main: " + obj.data);

        System.out.println("--------------------------------");

        // Call by Value example
        int x = 10;
        System.out.println("x before method call: " + x);
        callobj.change(x);
        System.out.println("x after method call: " + x);
    }
}