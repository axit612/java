class axit{
    void p1(){
        System.out.print("axit");
    }
}

class utsav extends axit{
    @Override
    void p1(){
        System.out.print("utsav");
    }
}
public class Polymorphism {
    public static void main(String atgs[]){
        axit u = new utsav();
        u.p1();
    }
}

