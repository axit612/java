public class LastLetterRegex {

    static void printLast(String word) {
        if (word.matches("[a-zA-Z]+")) {
            char lastChar = word.charAt(word.length() - 1);
            System.out.println("Output: " + lastChar);
        } else {
            System.out.println("Output: Not possible");
        }
    }
    public static void main(String[] args) {

        String input1 = "abc";
        String input2 = "adkfj12kfjalsd";

        printLast(input1);
        printLast(input2);
    }


}