
class demo2{
    int x = 40;
    int y = 50;
    class iner{
        void show(){
            System.out.println("sum :"+ (x+y));
        }
    }
}
public class program4 {
    public static void main(String args[]){
        demo2.iner in = new demo2().new iner();
        in.show();
    }
}
