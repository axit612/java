import java.io.*;
import java.util.*;
import java.util.logging.*;

public class Main {

    private static final String FILE_NAME = "employees.txt";
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        try {
            addEmployee(3, "Jay", 10000);
            System.out.println("After adding new employee:");
            getAllEmployees();

            deleteEmployee(2);
            System.out.println("\nAfter deleting 2 employee:");
            getAllEmployees();

            updateSalary(3, 10001);
            System.out.println("\nAfter changing salary of 3rd employee:");
            getAllEmployees();

        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error occurred", e);
        }
    }

    // ADD
    public static void addEmployee(int id, String name, int salary) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true));
        writer.write(id + "," + name + "," + salary);
        writer.newLine();
        writer.close();
        logger.info("Employee added: " + id);
    }

    // DELETE
    public static void deleteEmployee(int empId) throws IOException {
        File inputFile = new File(FILE_NAME);
        File tempFile = new File("temp.txt");

        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

        String line;
        while ((line = reader.readLine()) != null) {
            if (!line.startsWith(empId + ",")) {
                writer.write(line);
                writer.newLine();
            }
        }

        reader.close();
        writer.close();

        inputFile.delete();
        tempFile.renameTo(inputFile);
        logger.info("Employee deleted: " + empId);
    }

    // UPDATE SALARY
    public static void updateSalary(int empId, int newSalary) throws IOException {
        File inputFile = new File(FILE_NAME);
        File tempFile = new File("temp.txt");

        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            if (Integer.parseInt(data[0]) == empId) {
                line = data[0] + "," + data[1] + "," + newSalary;
            }
            writer.write(line);
            writer.newLine();
        }

        reader.close();
        writer.close();

        inputFile.delete();
        tempFile.renameTo(inputFile);
        logger.info("Salary updated for employee: " + empId);
    }

    // READ ALL
    public static void getAllEmployees() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME));
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line.replace(",", ", "));
        }
        reader.close();
    }
}