public class StringToByte {
    public static void main(String[] args) {

        String input = "abcs";
        byte[] bytes = input.getBytes();

        for (int i = 0; i < bytes.length; i++) {
            System.out.print(bytes[i]);
        }
    }
}
