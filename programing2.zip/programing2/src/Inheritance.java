class pass{
    void stud(String Name){
        System.out.println("student is a pass : " + Name);
    }
}

class notpass extends pass{
    void stud1(String Name){
        System.out.println("Student is a no pass :" + Name);
    }
}

public class Inheritance {
    public static void main(String args[]){
        notpass not = new notpass();
        not.stud("jay");
        not.stud1("Axit");

    }
}
