public class RemoveInvalid {
    public static void main(String[] args) {

        String s = ")123(abc))412";
        StringBuilder sb = new StringBuilder();
        int openCount = 0;
        int removed = 0;

        // -------- First pass: remove extra ')'
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);

            if (ch == '(') {
                openCount++;
                sb.append(ch);
            } else if (ch == ')') {
                if (openCount > 0) {
                    openCount--;
                    sb.append(ch);
                } else {
                    removed++; // invalid ')'
                }
            } else {
                sb.append(ch); // letters & numbers
            }
        }

        // -------- Second pass: remove extra '(' from end
        StringBuilder result = new StringBuilder();
        for (int i = sb.length() - 1; i >= 0; i--) {
            char ch = sb.charAt(i);

            if (ch == '(' && openCount > 0) {
                openCount--;
                removed++;
            } else {
                result.append(ch);
            }
        }

        result.reverse();

        System.out.println("Valid String: " + result.toString());
        System.out.println("Removed parentheses count: " + removed);
    }

}

