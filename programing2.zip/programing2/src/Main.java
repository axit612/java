//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    int x = 10;
    class p1{
        void p2(){
            System.out.println("value of x:"+x);
        }
    }
    public static void main(String[] args) {
        Main m = new Main();
        Main.p1 p = m.new p1();
        p.p2();
    }
}