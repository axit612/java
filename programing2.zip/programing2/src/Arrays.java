import java.util.*;
class a1{
    void display(int []number,int n){
        for(int i=0;i<n;i++){
            System.out.print("Value of "+i+" is : "+number[i]+"\n");
        }
    }
    void update(int []number,int n,int num,int value){

        for(int i=0;i<n;i++){
            if(number[i]==num){
                number[i]=value;
            }
        }

    }
}

public class Arrays {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.print("How many number you are Enter:");
        int n = sc.nextInt();
        int[] number = new int[n];

        for(int i=0;i<n;i++){
            System.out.print("Enter Value number "+i+" : ");
            number[i] = sc.nextInt();
        }
        a1 a = new a1();
        a.display(number,n);

        System.out.print("wiche index number you are update:");
        int num = sc.nextInt();
        System.out.print("Enter youer new number:");
        int value = sc.nextInt();

        a.update(number,n,num,value);
        a.display(number,n);


    }
}
