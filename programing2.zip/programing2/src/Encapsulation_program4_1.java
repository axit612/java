class p2{
    private int x=12,y=12;
    p2(){
        this.x = x;
        this.y = y;
    }

    void display(){
        System.out.println("sum of x and y : " + (x + y));
    }
}

class mythread1 extends Thread{
    @Override
    public void run(){
        p2 p = new p2();
        p.display();
    }
}

public class Encapsulation_program4_1 {
    public static void main(String args[]){
        mythread1 trad = new mythread1();
        trad.start();
    }
}
