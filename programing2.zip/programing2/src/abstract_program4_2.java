 abstract class TV{
    abstract void turnOn();
    abstract  void turnoff();
}

class p3 extends TV{
    @Override
    void turnOn(){
        System.out.println("TV ON");
    };
    @Override
    void turnoff(){
        System.out.println("TV Off");
    };
}

class t1 extends Thread{
    @Override
    public void run(){
        p3 turn = new p3();
        turn.turnOn();
        turn.turnoff();
    }
}

public class abstract_program4_2 {
    public static void main(String args[]){
        t1 Tread = new t1();
        Tread.start();
    }
}
